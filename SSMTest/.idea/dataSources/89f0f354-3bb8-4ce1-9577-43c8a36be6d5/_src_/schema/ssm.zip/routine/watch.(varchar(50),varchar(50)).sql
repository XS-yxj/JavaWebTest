CREATE PROCEDURE `watch`(IN `name_a` VARCHAR(50), IN `name_b` VARCHAR(50), OUT `w_result` INT(11))
  BEGIN
    DECLARE a_count int DEFAULT 0;
    START TRANSACTION ;
    insert ignore into friend(user_a, user_b)
    values(name_a, name_b);
    select row_count() into a_count;
    IF (a_count = 1) THEN
      set w_result = 1 ;
    ELSE
      delete from friend
      where user_a = name_a and user_b = name_b;
      set w_result = -1;
    END IF;
    COMMIT ;
  END